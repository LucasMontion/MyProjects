import './style.css';
import * as THREE from "three";
import {OrbitControls } from 'three/examples/jsm/controls/OrbitControls';


const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(100, window.innerWidth/window.innerHeight, 0.1,1000);

const renderer = new THREE.WebGLRenderer({
  canvas: document.querySelector('#bg'),
});


renderer.setPixelRatio( window.devicePixelRatio);
renderer.setSize(window.innerWidth, window.innerHeight);
camera.position.set(100,30,50);

renderer.render( scene, camera);


//Planets
const mercuryTexture = new THREE.TextureLoader().load('mercury.jfif');
const mercury = new THREE.Mesh(
  new THREE.SphereGeometry(0.3,100,100),
  new THREE.MeshStandardMaterial( {map: mercuryTexture})
);

scene.add(mercury)


const venusTexture = new THREE.TextureLoader().load('venus.jfif');
const venus = new THREE.Mesh(
  new THREE.SphereGeometry(0.9499, 100, 100),
  new THREE.MeshStandardMaterial( {map: venusTexture})
);

scene.add(venus)


const earthTexture = new THREE.TextureLoader().load('earth.jpg');
const earth = new THREE.Mesh(
  new THREE.SphereGeometry(1,100,100),
  new THREE.MeshStandardMaterial( {map: earthTexture })
);

scene.add(earth)


const marsTexture = new THREE.TextureLoader().load('mars.jfif');
const mars = new THREE.Mesh(
  new THREE.SphereGeometry(0.5,100,100),
  new THREE.MeshStandardMaterial( {map: marsTexture})
);

scene.add(mars)


const jupiterTexture = new THREE.TextureLoader().load('jupiter1.jfif');
const jupiter = new THREE.Mesh(
  new THREE.SphereGeometry(11,100,100),
  new THREE.MeshStandardMaterial( {map: jupiterTexture})
);

scene.add(jupiter)


const saturnTexture = new THREE.TextureLoader().load('saturn.jfif');
const saturn = new THREE.Mesh(
  new THREE.SphereGeometry(9,100,100),
  new THREE.MeshStandardMaterial({map: saturnTexture})
);
const saturnRingTexture = new THREE.TextureLoader().load('saturnRing3.jfif');
const saturnRing = new THREE.Mesh(
  new THREE.RingGeometry(10,15,64),
  new THREE.MeshStandardMaterial({map: saturnRingTexture})
);
scene.add(saturn)
scene.add(saturnRing)


const uranusTexture = new THREE.TextureLoader().load('uranus1.jfif');
const uranus = new THREE.Mesh(
  new THREE.SphereGeometry(4,100,100),
  new THREE.MeshStandardMaterial({map: uranusTexture})
);
scene.add(uranus)

const neptuneTexture = new THREE.TextureLoader().load('neptune1.jfif');
const neptune = new THREE.Mesh(
  new THREE.SphereGeometry(4,100,100),
  new THREE.MeshStandardMaterial({map: neptuneTexture})
);
scene.add(neptune)

const sunTexture = new THREE.TextureLoader().load('sun.jpg');
const geometry = new THREE.SphereGeometry(54.5,100,100);
const material = new THREE.MeshStandardMaterial({map: sunTexture})
const sun = new THREE.Mesh( geometry, material);

scene.add(sun)

//Lighting

const pointLight = new THREE.PointLight(0xfffff);
pointLight.position.set(1,1,1);

const ambientLight = new THREE.AmbientLight(0xffffff);

scene.add(pointLight, ambientLight)


//const lightHelper = new THREE.PointLightHelper(pointLight);
//const gridHelper = new THREE.GridHelper(500, 500);
//scene.add(lightHelper, gridHelper)


//Controls
const controls = new OrbitControls(camera, renderer.domElement);


//Stars
function addStar() {
  const geometry = new THREE.SphereGeometry(0.25, 24, 24);
  const material = new THREE.MeshStandardMaterial({ color: 0xffffff });
  const star = new THREE.Mesh(geometry, material);

  const [x, y, z] = Array(3)
    .fill()
    .map(() => THREE.MathUtils.randFloatSpread(1000));

  star.position.set(x, y, z);
  scene.add(star);
}

Array(200).fill().forEach(addStar);


mercury.position.x = 70;
venus.position.x = 90;
earth.position.x = 110;
mars.position.x = 125;
jupiter.position.x = 150;
saturn.position.x = 205;
saturnRing.position.x = 205;
uranus.position.x = 240;
neptune.position.x = 260;

//Animates the site
function animate() {
  requestAnimationFrame( animate);

  sun.rotation.y += 0.00041667;
  mercury.rotation.y += 0.1;
  venus.rotation.y += 0.0001;
  earth.rotation.y += 0.01;
  mars.rotation.y += 0.005;
  jupiter.rotation.y += 0.01;
  saturn.rotation.y += 0.01;
  saturnRing.rotation.z += 0.01;
  saturnRing.rotation.x = (-Math.PI / 2) + (0.27);
  


  controls.update()

  renderer.render(scene, camera);
}

animate()